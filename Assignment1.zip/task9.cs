using System;

namespace Assignment1
{
    class task9
    {
        static void Main(string[] args)
        {
            //Taking a number as an input from user, and printing its factorial.
            Console.WriteLine("Enter a number");
            int number = int.Parse(Console.ReadLine());
            int factorial = 1;
            if (number >= 0){
                for (int i = 1; i <= number; i++) {
                    //here it is computing n(n-1)(n-2)...1
                    //n=number(where upto find factorial of a number)
                    factorial = factorial * i;    
                }
                Console.WriteLine("Factorial is = " + factorial);
            }
            else {
                Console.WriteLine("Number is less than zero");
            }
        }
    }
}