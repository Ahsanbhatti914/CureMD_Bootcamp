using System;

namespace Assignment1
{
    class task4
    {
        static void Main(string[] args)
        {
            //Taking a number as an input and print its square.
            Console.WriteLine("Enter a number!");
            int number = int.Parse(Console.ReadLine());
            Console.WriteLine("Square of " + number + " is = " + (number * number));
        }
    }
}