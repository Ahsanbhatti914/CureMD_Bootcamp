using System;

namespace Assignment1
{
    class task3
    {
        static void Main(string[] args)
        {
			//Taking two numbers as an input and printing their sum
            Console.WriteLine("Enter First Number!");
            double number1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter Second Number!");
            double number2 = double.Parse(Console.ReadLine());

            Console.WriteLine("Sum of two number is = " + (number1 + number2));
        }
    }
}
