using System;

namespace Assignment1
{
    class task2
    {
        //Taking user name as an input, and greeting him/her
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter your good name!");
            string name = Console.ReadLine();
            Console.WriteLine("Hello, " + name);
        }
    }
}
