using System;

namespace Assignment1
{
    class task7
    {
        static void Main(string[] args)
        {
            //Printing multiplication table of any number upto 12
            Console.WriteLine("Enter a number");
            int number = int.Parse(Console.ReadLine());
            if (number > 0){
                for (int i = 1; i <= 12; i++) {
                    Console.WriteLine(number + " X " + i + " = " + number * i);
                }
            }
            else {
                Console.WriteLine("Number is less than one!!!");
            }
        }
    }
}