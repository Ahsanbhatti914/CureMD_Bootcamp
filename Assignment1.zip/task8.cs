using System;

namespace Assignment1
{
    class task8
    {
        static void Main(string[] args)
        {
            //Taking a number as an input from user, and printing all prime numbers upto n.
            Console.WriteLine("Enter a number");
            int number = int.Parse(Console.ReadLine());
            bool isPrime = true;
            Console.Write("Prime Number : ");
            for (int value = 2; value <= number; value++) { //this loop generating numbers upto n
                for (int j = 2; j < value; j++) {
                    //this loop is checking either the value is divisible by any number
                    //rather than 0 and its own value
                    if (value % j == 0) {
                        isPrime = false;
                    }
                }
                if (isPrime) {
                    Console.Write(value + " ");
                }
                isPrime = true;
            }
        }
    }
}