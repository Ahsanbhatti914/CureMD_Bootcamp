using System;

namespace Assignment1
{
    class task5
    {
        static void Main(string[] args)
        {
            //Printing all even numbers from 1 to 100
            for (int i = 1; i <= 100; i++) {
                //Checking either a number has remainder or not, if not then, it is an even number
                if (i % 2 == 0) {
                    Console.WriteLine(i);
                }
            }
        }
    }
}
