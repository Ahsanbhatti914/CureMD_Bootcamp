using System;

namespace Assignment1
{
    class task6
    {
        static void Main(string[] args)
        {
            //Taking a number n from user, computing sum from 1 to n
            Console.WriteLine("Enter a number");
            int number = int.Parse(Console.ReadLine());
            int sum = 0;
            if (number > 0){
                for (int i = 1; i <= number; i++) {
                    sum = sum + i; //computing sum from 1 to n
                }
                Console.WriteLine("Sum is = " + sum);
            }
            else {
                Console.WriteLine("Number is less than one!!!");
            }
        }
    }
}
