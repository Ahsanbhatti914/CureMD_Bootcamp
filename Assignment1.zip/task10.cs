using System;

namespace Assignment1
{
    class task10
    {
        static void Main(string[] args)
        {
            //Taking a number as an input from user, and printing Fibonacci sequence upto n term.
            //0,1,1,2,3,5,8,13
            Console.WriteLine("Enter a number");
            int number = int.Parse(Console.ReadLine());
            int fibonacci;
            int term1 = 1;
            int term2 = 0;
            if (number > 0) {
                Console.Write("Fibonacci : ");
                for (int i = 0; i < number; i++) {
                    if (i < 2){
                        //printing first two fibonacci sequence number
                        Console.Write(i + " ");
                    }
                    else{
                        //computing the sum of previous two numbers
                        fibonacci = term1 + term2;
                        Console.Write(fibonacci + " ");
                        //term2 moving to term1 and term1 moving to fibonacci so that they can
                        //create next fibonacci sequence number
                        term2 = term1;
                        term1 = fibonacci;
                    }
                }
            } else {
                Console.WriteLine("Number is less than one!!!");
            }
        }
    }
}