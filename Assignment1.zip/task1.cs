using System;

namespace Assignment1
{
    class task1
    {
        //Printing 'Hello, World!'
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
}