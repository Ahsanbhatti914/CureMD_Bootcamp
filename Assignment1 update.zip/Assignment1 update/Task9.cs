using System;

namespace Assignment1
{
    class Task9
    {
        static void Main(string[] args)
        {
            //Taking a number as an input and printing a pattern
            Console.WriteLine("Enter a height");
            int height = int.Parse(Console.ReadLine());
            for (int i = 1; i <= height; i++) {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write(j);
                }
                Console.WriteLine();
            }
        }
    }
}