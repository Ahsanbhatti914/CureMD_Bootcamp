using System;

namespace Assignment1
{
    class Task8
    {
        static void Main(string[] args)
        {
            //Taking a number as an input checking either it is perfect number or not
            Console.Write("Enter a number ");
            int number = int.Parse(Console.ReadLine());
            int isPerfect = 0;
            for (int i = 1; i < number; i++)
            {
                //this line checking a  numebr has any divisor?
                //if yes, then adding that divisor into isPerfect variable.
                if (number % i == 0) { isPerfect = isPerfect + i; }
            }
            if (isPerfect == number) { Console.WriteLine(number + " is a perfect number"); }
            else { Console.WriteLine(number + " is not a perfect number"); }
        }
            
    }
}