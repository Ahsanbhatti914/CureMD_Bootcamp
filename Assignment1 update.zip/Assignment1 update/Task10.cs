using System;

namespace Assignment1
{
    class Task10
    {
        static void Main(string[] args)
        {
            //Finding subsequence of two srting
            string str1 = "ABCDGH";
            string str2 = "AEDFHR";
            string sequence = "";
        
            for (int i = 0; i < str1.Length; i++){
                //checking character by character
                for (int j = 0; j < str2.Length; j++){
                    if (str1[i] == str2[j]) { sequence = sequence + str1[i]; }
                }
            }

            if (sequence == "") { Console.WriteLine("No sequence found!!!"); }
            else { Console.WriteLine("sequence = " + sequence); }
        }
            
    }
}