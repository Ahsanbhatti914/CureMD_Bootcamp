using System;

namespace Assignment1
{
    class task6
    {
        static void Main(string[] args)
        {
            //Taking a string as an input and print its reverse
            Console.WriteLine("Enter a string");
            string str = Console.ReadLine();
            string reverse = "";
            Console.Write("Prime Number : ");
            for (int i = str.Length - 1; i >= 0; i--) {
                reverse = reverse + str[i];
            }
            Console.WriteLine(reverse);
        }
    }
}