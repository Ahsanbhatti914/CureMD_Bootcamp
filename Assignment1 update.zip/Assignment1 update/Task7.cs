using System;

namespace Assignment1
{
    class Task7
    {
        static void Main(string[] args)
        {
            //Taking numbers input in an array and sorting it
            int[] numbers = new int[5];
            bool isSwapped = false;
            for (int i = 0; i < numbers.Length; i++) {
                Console.Write("Enter element " + i + " = ");
                numbers[i] = int.Parse(Console.ReadLine());
            }
            
            for (int i = 0; i < numbers.Length - 1; i++) {
                //Basiclly inner loop helps in placing larger value at extreme right place.
                for (int j = 0; j < numbers.Length-1-i; j++)
                {
                    if (numbers[j] > numbers[j + 1]) {
                        int temp = numbers[j + 1];
                        numbers[j + 1] = numbers[j];
                        numbers[j] = temp;
                        isSwapped = true;
                    }
                }
                //this statement is checking is there any swap happened,
                //if no then the array is already sorted and we are making our code efficient
                if (!isSwapped) { break; }
            }

            for (int i = 0; i < numbers.Length; i++){
                Console.Write(numbers[i]+" ");
            }
        }
    }
}