﻿using ASP.NET_Core_Web_API.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Data;

namespace ASP.NET_Core_Web_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CoursesController : ControllerBase
    {
        private readonly string _connectionString;

        public CoursesController(Microsoft.Extensions.Configuration.IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("Default");
            Console.WriteLine(_connectionString);
        }

        [HttpGet]
        public IActionResult GetAllCourses()
        {
            List<Course> courses = new List<Course>();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("GetAllCourses", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Course course = new Course();

                        course.CourseID = (int)reader["CourseID"];
                        course.CourseName = reader["CourseName"].ToString();
                        courses.Add(course);

                    }
                }
            }
            return Ok(courses);
        }

        [HttpPost]
        public IActionResult AddCourse(Course course)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("AddNewCourse", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CourseID", course.CourseID);
                    command.Parameters.AddWithValue("@CourseName", course.CourseName);
                    command.ExecuteNonQuery();

                }
            }
            return Ok("DATA SAVED!!!");
        }

        [HttpPut("{id}")]
        public IActionResult UpdateCourse(int id,Course course)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("UpdateCourse", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CourseID", id);
                    command.Parameters.AddWithValue("@CourseName", course.CourseName);
                    command.ExecuteNonQuery();

                }
            }
            return Ok("DATA UPDATED!!!");
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCourse(int id)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("DeleteCourse", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CourseID", id);
                    command.ExecuteNonQuery();

                }
            }
            return Ok("DATA DELETED!!!");
        }
    }
}
