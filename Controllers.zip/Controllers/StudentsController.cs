﻿using ASP.NET_Core_Web_API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ASP.NET_Core_Web_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StudentsController : ControllerBase
    {
        private readonly string _connectionString;

        public StudentsController(Microsoft.Extensions.Configuration.IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("Default");
            Console.WriteLine(_connectionString);
        }

        [HttpGet]
        public IActionResult GetAllStudents()
        {
            List<Student> students = new List<Student>();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("GetAllStudents", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Student std = new Student();

                        std.StudentID = (int)reader["StudentID"];
                        std.FirstName = reader["FirstName"].ToString();
                        std.LastName = reader["LastName"].ToString();
                        std.Age = (int)reader["Age"];
                        std.CourseID = (int)reader["CourseID"];
                        students.Add(std);

                    }
                }
            }
            return Ok(students);
        }

        [HttpPost]
        public IActionResult AddStudent(Student std)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("Add_Student", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@StudentID", std.StudentID );
                    command.Parameters.AddWithValue("@FirstName", std.FirstName);
                    command.Parameters.AddWithValue("@LastName", std.LastName);
                    command.Parameters.AddWithValue("@Age", std.Age);
                    command.Parameters.AddWithValue("@CourseID", std.CourseID);
                    command.ExecuteNonQuery();

                }
            }
            return Ok("DATA SAVED!!!");
        }


        [HttpPut("{id}")]
        [Route("Edit")]
        public IActionResult UpdateStudent(int studentID, Student std)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("Update_Student", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@StudentID", studentID);
                    command.Parameters.AddWithValue("@FirstName", std.FirstName);
                    command.Parameters.AddWithValue("@LastName", std.LastName);
                    command.Parameters.AddWithValue("@Age", std.Age);
                    command.Parameters.AddWithValue("@CourseID", std.CourseID);
                    command.ExecuteNonQuery();

                }
            }
            return Ok("DATA UPDAETD!!!");
        }

        [HttpDelete("{id}")]
        [Route("Delete")]
        public IActionResult DeleteStudent(int studentID)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("Delete_Student", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@StudentID", studentID);
                    command.ExecuteNonQuery();

                }
            }
            return Ok("DATA DELETED!!!");
        }

        [HttpGet]
        [Route("StudentsGreaterThanTwenty")]
        public IActionResult StudentsGreaterThanTwenty()
        {
            List<Student> students = new List<Student>();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("Students_Greater_Than_Twenty", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Student std = new Student();

                        std.StudentID = (int)reader["StudentID"];
                        std.FirstName = reader["FirstName"].ToString();
                        std.LastName = reader["LastName"].ToString();
                        std.Age = (int)reader["Age"];
                        std.CourseID = (int)reader["CourseID"];
                        students.Add(std);

                    }
                }
            }
            return Ok(students);
        }

        [HttpGet]
        [Route("StudentsEnrolledInSpecificCourse/{CourseID:int}")]
        public IActionResult StudentsEnrolledInSpecificCourse(int CourseID)
        {
            List<Student> students = new List<Student>();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("Students_Enrolled_In_Specific_Course", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CourseID", CourseID);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Student std = new Student();

                        std.StudentID = (int)reader["StudentID"];
                        std.FirstName = reader["FirstName"].ToString();
                        std.LastName = reader["LastName"].ToString();
                        std.Age = (int)reader["Age"];
                        std.CourseID = (int)reader["CourseID"];
                        students.Add(std);

                    }
                }
            }
            return Ok(students);
        }

        [HttpGet]
        [Route("MostPopularCourse")]
        public IActionResult MostPopularCourse()
        {
            List<Course> courses = new List<Course>();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("Most_Popular_Course", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Course course = new Course();

                        course.CourseID = (int)reader["CourseID"];
                        course.CourseName = reader["CourseName"].ToString();

                        courses.Add(course);
                    }
                }
            }
            return Ok(courses);
        }
    }
}
