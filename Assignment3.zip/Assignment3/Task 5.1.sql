SELECT *
FROM Students
WHERE Age > 20