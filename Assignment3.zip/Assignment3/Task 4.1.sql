UPDATE Students
SET Age = 17
WHERE StudentID = 1