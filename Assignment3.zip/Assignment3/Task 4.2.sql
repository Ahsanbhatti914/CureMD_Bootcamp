DELETE Students
WHERE StudentID = 13