INSERT INTO Students (StudentID,FirstName,LastName,Age,CourseID) VALUES
(1,'Ahsan','Ayub',10,101),
(2,'Fahad','Akeel',15,102),
(3,'Muhammad','Jawad',20,101),
(4,'Waleed','Khan',25,101),
(5,'Rehan','Jamshaid',30,103),
(6,'Daniyal','Mateen',40,103),
(7,'Basiq','Naeem',45,101),
(8,'Kashif','Saddiq',50,104),
(9,'Shaban','Ali',55,102),
(10,'Umar','Sajjad',60,101),
(11,'Muhammad','Shazad',65,103),
(13,'Taha','Amir',70,103),
(14,'Bilal','Faisal',75,104)