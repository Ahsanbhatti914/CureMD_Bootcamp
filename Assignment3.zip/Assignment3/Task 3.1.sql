INSERT INTO Courses (CourseID,CourseName) VALUES
(101,'PF'),
(102,'OOP'),
(103,'DSA'),
(104,'WEB'),
(105,'OS')