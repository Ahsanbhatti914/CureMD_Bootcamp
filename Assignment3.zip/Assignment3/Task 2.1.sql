CREATE TABLE Students(
StudentID INT PRIMARY KEY,
FirstName VARCHAR(50),
LastName VARCHAR(50),
Age INT,
CourseID INT,
CONSTRAINT CourseID_fk FOREIGN KEY (CourseID) REFERENCES Courses(CourseID)
)
