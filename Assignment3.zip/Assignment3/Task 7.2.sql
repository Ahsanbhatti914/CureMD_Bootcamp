SELECT * FROM Courses
WHERE CourseID = (
	SELECT CourseID FROM(
				SELECT S.CourseID AS CourseID,COUNT(S.CourseID) AS CourseCount
				FROM Students S JOIN Courses C
				ON S.CourseID = C.CourseID
				GROUP BY S.CourseID
				ORDER BY CourseCount DESC
				OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY 
		)AS CourseID
)