SELECT AVG(Age)
FROM Students