SELECT S.FirstName, S.LastName,C.CourseName
FROM Students S JOIN Courses C
ON S.CourseID = C.CourseID
WHERE C.CourseName = 'OOP'