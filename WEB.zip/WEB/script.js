var students = [];
var courses = [];


function addStudent(){
    var sid = $('#std_id').val();
     var fname = $('#std_fname').val();
     var lname = $('#std_lname').val();
     var age = $('#std_age').val();
     var cid = $('#std_cid').val();

     var student = {
         sid:sid,
         fname:fname,
         lname:lname,
         age:age,
         cid:cid
     };

    students.push(student);
    $('#students_list').empty();
    students.forEach(function(std) {
        $('#students_list').append('<li>' + std.sid + ', ' + std.fname + ', ' + std.lname + ', ' + std.age + ', ' + std.cid + '</li>');
    });
}

function addCourse(){
    var cid = $('#cid').val();
    var cname = $('#cname').val();

     var course = {
         cid:cid,
         cname:cname
     };

    courses.push(course);
    $('#courses_list').empty();
    courses.forEach(function(course) {
        $('#courses_list').append('<li>' + course.cid + ', ' + course.cname + '</li>');
    });
}