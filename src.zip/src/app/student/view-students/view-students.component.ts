import { Component, OnInit } from '@angular/core';
import { DataServiceService } from '../../Services/data-service.service';

@Component({
  selector: 'app-view-students',
  templateUrl: './view-students.component.html',
  styleUrls: ['./view-students.component.css']
})
export class ViewStudentsComponent implements OnInit {
  students:any;
  constructor(private dataService:DataServiceService){}
  ngOnInit(): void {
  this.dataService.getAllUsers().subscribe((data)=>{
    this.students = data;
  });
  }
    
}
