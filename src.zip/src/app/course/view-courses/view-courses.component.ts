import { Component, OnInit } from '@angular/core';
import {DataServiceService} from '../../Services/data-service.service';

@Component({
  selector: 'app-view-courses',
  templateUrl: './view-courses.component.html',
  styleUrls: ['./view-courses.component.css']
})
export class ViewCoursesComponent implements OnInit{
  courses:any;
  constructor(private dataService:DataServiceService){}

  ngOnInit(): void {
    this.dataService.getAllCourses().subscribe((data)=>{
      this.courses = data;
    })
  }

}
