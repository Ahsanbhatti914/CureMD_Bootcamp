import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StudentComponent } from './student/student.component';
import { CourseComponent } from './course/course.component';
import { AddStudentComponent } from './student/add-student/add-student.component';
import { ViewStudentsComponent } from './student/view-students/view-students.component';
import { UpdateStudentComponent } from './student/update-student/update-student.component';
import { DeleteStudentComponent } from './student/delete-student/delete-student.component';
import { AddCourseComponent } from './course/add-course/add-course.component';
import { ViewCoursesComponent } from './course/view-courses/view-courses.component';
import { UpdateCourseComponent } from './course/update-course/update-course.component';
import { DeleteCourseComponent } from './course/delete-course/delete-course.component';
import {HttpClientModule} from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    StudentComponent,
    CourseComponent,
    AddStudentComponent,
    ViewStudentsComponent,
    UpdateStudentComponent,
    DeleteStudentComponent,
    AddCourseComponent,
    ViewCoursesComponent,
    UpdateCourseComponent,
    DeleteCourseComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
